<?php
$popupMeta = array (
    'moduleMain' => 'ECiu_crm_training_goals',
    'varName' => 'ECiu_crm_training_goals',
    'orderBy' => 'eciu_crm_training_goals.name',
    'whereClauses' => array (
  'name' => 'eciu_crm_training_goals.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
),
);
