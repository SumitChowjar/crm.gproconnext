<?php
$module_name = 'ECiu_crm_training_goals';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'Y2016' => 
  array (
    'type' => 'int',
    'label' => 'LBL_Y2016',
    'width' => '10%',
    'default' => true,
  ),
  'Y2017' => 
  array (
    'type' => 'int',
    'label' => 'LBL_Y2017',
    'width' => '10%',
    'default' => true,
  ),
  'Y2018' => 
  array (
    'type' => 'int',
    'label' => 'LBL_Y2018',
    'width' => '10%',
    'default' => true,
  ),
  'Y2019' => 
  array (
    'type' => 'int',
    'label' => 'LBL_Y2019',
    'width' => '10%',
    'default' => true,
  ),
  'Y2020' => 
  array (
    'type' => 'int',
    'label' => 'LBL_Y2020',
    'width' => '10%',
    'default' => true,
  ),
);
?>
