<?php
// created: 2018-01-22 10:14:22
$dictionary["gpro_Courses"]["fields"]["gpro_courses_eciu_crm_resources"] = array (
  'name' => 'gpro_courses_eciu_crm_resources',
  'type' => 'link',
  'relationship' => 'gpro_courses_eciu_crm_resources',
  'source' => 'non-db',
  'module' => 'ECiu_crm_resources',
  'bean_name' => 'ECiu_crm_resources',
  'side' => 'right',
  'vname' => 'LBL_GPRO_COURSES_ECIU_CRM_RESOURCES_FROM_ECIU_CRM_RESOURCES_TITLE',
);
