<?php
$dashletData['ECiu_resourcesDashlet']['searchFields'] = array (
  'resource_id' => 
  array (
    'default' => '',
  ),
  'name' => 
  array (
    'default' => '',
  ),
);
$dashletData['ECiu_resourcesDashlet']['columns'] = array (
  'resource_id' => 
  array (
    'type' => 'int',
    'label' => 'LBL_RESOURCE_ID',
    'width' => '10%',
    'default' => true,
  ),
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
);
