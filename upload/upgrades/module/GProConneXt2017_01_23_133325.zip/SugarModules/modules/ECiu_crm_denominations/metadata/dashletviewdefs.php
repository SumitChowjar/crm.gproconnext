<?php
$dashletData['ECiu_crm_denominationsDashlet']['searchFields'] = array (
  'denomination_id' => 
  array (
    'default' => '',
  ),
  'name' => 
  array (
    'default' => '',
  ),
);
$dashletData['ECiu_crm_denominationsDashlet']['columns'] = array (
  'denomination_id' => 
  array (
    'type' => 'int',
    'label' => 'LBL_DENOMINATION_ID',
    'width' => '10%',
    'default' => true,
  ),
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
);
