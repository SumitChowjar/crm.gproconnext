<?php
$dashletData['ECiu_crm_ddcDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
);
$dashletData['ECiu_crm_ddcDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
);
