<?php
$dashletData['ECiu_crm_calendar_periodsDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'base_weeknum' => 
  array (
    'default' => '',
  ),
  'base_month' => 
  array (
    'default' => '',
  ),
  'base_quarter' => 
  array (
    'default' => '',
  ),
  'base_year' => 
  array (
    'default' => '',
  ),
  'base_semester' => 
  array (
    'default' => '',
  ),
);
$dashletData['ECiu_crm_calendar_periodsDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'base_weeknum' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_WEEKNUM',
    'width' => '10%',
    'default' => true,
    'name' => 'base_weeknum',
  ),
  'base_month' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_MONTH',
    'width' => '10%',
    'default' => true,
    'name' => 'base_month',
  ),
  'base_quarter' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_QUARTER',
    'width' => '10%',
    'default' => true,
    'name' => 'base_quarter',
  ),
  'base_semester' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_SEMESTER',
    'width' => '10%',
    'default' => true,
  ),
);
