<?php
$module_name = 'igwt_resource_types';
$listViewDefs [$module_name] = 
array (
  'CATEGORY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CATEGORY',
    'width' => '10%',
    'default' => true,
  ),
  'SUB_CATEGORY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SUB_CATEGORY',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
);
?>
