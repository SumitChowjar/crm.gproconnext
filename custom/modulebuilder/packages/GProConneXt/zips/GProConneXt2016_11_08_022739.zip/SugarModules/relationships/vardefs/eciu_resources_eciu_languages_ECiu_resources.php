<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resources"]["fields"]["eciu_resources_eciu_languages"] = array (
  'name' => 'eciu_resources_eciu_languages',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_languages',
  'source' => 'non-db',
  'module' => 'ECiu_languages',
  'bean_name' => false,
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_LANGUAGES_FROM_ECIU_LANGUAGES_TITLE',
);
