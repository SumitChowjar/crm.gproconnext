<?php
// created: 2016-11-08 02:27:39
$dictionary["ECiu_crm_resources"]["fields"]["eciu_crm_resources_eciu_crm_resource_types"] = array (
  'name' => 'eciu_crm_resources_eciu_crm_resource_types',
  'type' => 'link',
  'relationship' => 'eciu_crm_resources_eciu_crm_resource_types',
  'source' => 'non-db',
  'module' => 'ECiu_crm_resource_types',
  'bean_name' => 'ECiu_crm_resource_types',
  'vname' => 'LBL_ECIU_CRM_RESOURCES_ECIU_CRM_RESOURCE_TYPES_FROM_ECIU_CRM_RESOURCE_TYPES_TITLE',
);
