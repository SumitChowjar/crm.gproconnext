<?php
$module_name = 'igwt_denominations';
$listViewDefs [$module_name] = 
array (
  'DENOMINATION_ID' => 
  array (
    'type' => 'int',
    'label' => 'LBL_DENOMINATION_ID',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '80%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
);
?>
