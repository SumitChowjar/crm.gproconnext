<?php
$module_name = 'ECiu_crm_calendar_periods';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'BASE_WEEKNUM' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_WEEKNUM',
    'width' => '10%',
    'default' => true,
  ),
  'BASE_MONTH' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_MONTH',
    'width' => '10%',
    'default' => true,
  ),
  'BASE_QUARTER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_QUARTER',
    'width' => '10%',
    'default' => true,
  ),
  'BASE_YEAR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_YEAR',
    'width' => '10%',
    'default' => true,
  ),
);
?>
