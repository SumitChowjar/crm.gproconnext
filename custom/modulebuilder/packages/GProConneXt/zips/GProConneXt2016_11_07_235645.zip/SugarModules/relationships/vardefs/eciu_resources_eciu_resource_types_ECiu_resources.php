<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resources"]["fields"]["eciu_resources_eciu_resource_types"] = array (
  'name' => 'eciu_resources_eciu_resource_types',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_resource_types',
  'source' => 'non-db',
  'module' => 'ECiu_resource_types',
  'bean_name' => 'ECiu_resource_types',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_RESOURCE_TYPES_FROM_ECIU_RESOURCE_TYPES_TITLE',
);
