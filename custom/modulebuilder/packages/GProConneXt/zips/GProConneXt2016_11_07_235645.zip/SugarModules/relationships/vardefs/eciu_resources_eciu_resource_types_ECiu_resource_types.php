<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resource_types"]["fields"]["eciu_resources_eciu_resource_types"] = array (
  'name' => 'eciu_resources_eciu_resource_types',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_resource_types',
  'source' => 'non-db',
  'module' => 'ECiu_resources',
  'bean_name' => 'ECiu_resources',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_RESOURCE_TYPES_FROM_ECIU_RESOURCES_TITLE',
);
