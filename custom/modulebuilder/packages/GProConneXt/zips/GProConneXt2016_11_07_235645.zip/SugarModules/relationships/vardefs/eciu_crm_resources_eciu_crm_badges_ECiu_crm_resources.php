<?php
// created: 2016-11-07 23:56:45
$dictionary["ECiu_crm_resources"]["fields"]["eciu_crm_resources_eciu_crm_badges"] = array (
  'name' => 'eciu_crm_resources_eciu_crm_badges',
  'type' => 'link',
  'relationship' => 'eciu_crm_resources_eciu_crm_badges',
  'source' => 'non-db',
  'module' => 'ECiu_crm_badges',
  'bean_name' => 'ECiu_crm_badges',
  'vname' => 'LBL_ECIU_CRM_RESOURCES_ECIU_CRM_BADGES_FROM_ECIU_CRM_BADGES_TITLE',
);
