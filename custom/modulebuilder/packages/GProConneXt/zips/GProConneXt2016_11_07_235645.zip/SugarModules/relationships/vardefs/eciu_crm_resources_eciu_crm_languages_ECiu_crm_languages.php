<?php
// created: 2016-11-07 23:56:45
$dictionary["ECiu_crm_languages"]["fields"]["eciu_crm_resources_eciu_crm_languages"] = array (
  'name' => 'eciu_crm_resources_eciu_crm_languages',
  'type' => 'link',
  'relationship' => 'eciu_crm_resources_eciu_crm_languages',
  'source' => 'non-db',
  'module' => 'ECiu_crm_resources',
  'bean_name' => 'ECiu_crm_resources',
  'vname' => 'LBL_ECIU_CRM_RESOURCES_ECIU_CRM_LANGUAGES_FROM_ECIU_CRM_RESOURCES_TITLE',
);
