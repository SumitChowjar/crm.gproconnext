<?php
$module_name = 'ECiu_crm_tracks';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '80%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
);
?>
