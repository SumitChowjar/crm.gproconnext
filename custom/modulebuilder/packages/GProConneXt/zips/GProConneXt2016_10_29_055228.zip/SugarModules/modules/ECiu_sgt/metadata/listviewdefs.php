<?php
$module_name = 'ECiu_sgt';
$listViewDefs [$module_name] = 
array (
  'SGT_ID' => 
  array (
    'type' => 'int',
    'label' => 'LBL_SGT_ID',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '80%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
);
?>
