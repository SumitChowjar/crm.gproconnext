<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_badges"]["fields"]["eciu_resources_eciu_badges"] = array (
  'name' => 'eciu_resources_eciu_badges',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_badges',
  'source' => 'non-db',
  'module' => 'ECiu_resources',
  'bean_name' => 'ECiu_resources',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_BADGES_FROM_ECIU_RESOURCES_TITLE',
);
