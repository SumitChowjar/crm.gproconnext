<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resources"]["fields"]["eciu_resources_eciu_tracks"] = array (
  'name' => 'eciu_resources_eciu_tracks',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_tracks',
  'source' => 'non-db',
  'module' => 'ECiu_tracks',
  'bean_name' => 'ECiu_tracks',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_TRACKS_FROM_ECIU_TRACKS_TITLE',
);
