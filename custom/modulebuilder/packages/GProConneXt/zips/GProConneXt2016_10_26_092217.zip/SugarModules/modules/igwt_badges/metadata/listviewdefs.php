<?php
$module_name = 'igwt_badges';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'HOW_TO_OBTAIN' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_HOW_TO_OBTAIN',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
);
?>
