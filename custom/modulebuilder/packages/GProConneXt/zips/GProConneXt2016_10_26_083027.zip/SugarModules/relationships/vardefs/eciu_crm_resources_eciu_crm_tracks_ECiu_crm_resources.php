<?php
// created: 2016-10-26 08:30:27
$dictionary["ECiu_crm_resources"]["fields"]["eciu_crm_resources_eciu_crm_tracks"] = array (
  'name' => 'eciu_crm_resources_eciu_crm_tracks',
  'type' => 'link',
  'relationship' => 'eciu_crm_resources_eciu_crm_tracks',
  'source' => 'non-db',
  'module' => 'ECiu_crm_tracks',
  'bean_name' => false,
  'vname' => 'LBL_ECIU_CRM_RESOURCES_ECIU_CRM_TRACKS_FROM_ECIU_CRM_TRACKS_TITLE',
);
