<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_denominations"]["fields"]["eciu_resources_eciu_denominations"] = array (
  'name' => 'eciu_resources_eciu_denominations',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_denominations',
  'source' => 'non-db',
  'module' => 'ECiu_resources',
  'bean_name' => 'ECiu_resources',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_DENOMINATIONS_FROM_ECIU_RESOURCES_TITLE',
);
