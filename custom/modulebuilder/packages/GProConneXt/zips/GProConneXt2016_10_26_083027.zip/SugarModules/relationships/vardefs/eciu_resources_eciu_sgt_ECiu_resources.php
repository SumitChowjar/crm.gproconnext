<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resources"]["fields"]["eciu_resources_eciu_sgt"] = array (
  'name' => 'eciu_resources_eciu_sgt',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_sgt',
  'source' => 'non-db',
  'module' => 'ECiu_sgt',
  'bean_name' => 'ECiu_sgt',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_SGT_FROM_ECIU_SGT_TITLE',
);
