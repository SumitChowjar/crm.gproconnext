<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resources"]["fields"]["eciu_resources_eciu_ddc"] = array (
  'name' => 'eciu_resources_eciu_ddc',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_ddc',
  'source' => 'non-db',
  'module' => 'ECiu_ddc',
  'bean_name' => 'ECiu_ddc',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_DDC_FROM_ECIU_DDC_TITLE',
);
