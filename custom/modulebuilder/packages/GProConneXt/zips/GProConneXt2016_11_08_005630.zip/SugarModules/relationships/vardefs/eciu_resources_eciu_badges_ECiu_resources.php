<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_resources"]["fields"]["eciu_resources_eciu_badges"] = array (
  'name' => 'eciu_resources_eciu_badges',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_badges',
  'source' => 'non-db',
  'module' => 'ECiu_badges',
  'bean_name' => 'ECiu_badges',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_BADGES_FROM_ECIU_BADGES_TITLE',
);
