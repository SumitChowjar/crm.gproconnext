<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_sgt"]["fields"]["eciu_resources_eciu_sgt"] = array (
  'name' => 'eciu_resources_eciu_sgt',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_sgt',
  'source' => 'non-db',
  'module' => 'ECiu_resources',
  'bean_name' => 'ECiu_resources',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_SGT_FROM_ECIU_RESOURCES_TITLE',
);
