<?php
// created: 2016-11-08 00:56:30
$dictionary["ECiu_crm_resources"]["fields"]["eciu_crm_resources_eciu_crm_ddc"] = array (
  'name' => 'eciu_crm_resources_eciu_crm_ddc',
  'type' => 'link',
  'relationship' => 'eciu_crm_resources_eciu_crm_ddc',
  'source' => 'non-db',
  'module' => 'ECiu_crm_ddc',
  'bean_name' => 'ECiu_crm_ddc',
  'vname' => 'LBL_ECIU_CRM_RESOURCES_ECIU_CRM_DDC_FROM_ECIU_CRM_DDC_TITLE',
);
