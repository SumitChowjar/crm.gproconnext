<?php
// created: 2016-10-26 08:14:12
$dictionary["ECiu_tracks"]["fields"]["eciu_resources_eciu_tracks"] = array (
  'name' => 'eciu_resources_eciu_tracks',
  'type' => 'link',
  'relationship' => 'eciu_resources_eciu_tracks',
  'source' => 'non-db',
  'module' => 'ECiu_resources',
  'bean_name' => 'ECiu_resources',
  'vname' => 'LBL_ECIU_RESOURCES_ECIU_TRACKS_FROM_ECIU_RESOURCES_TITLE',
);
