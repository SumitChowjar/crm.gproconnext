<?php
// created: 2016-11-08 00:56:30
$dictionary["Contact"]["fields"]["eciu_crm_resources_contacts"] = array (
  'name' => 'eciu_crm_resources_contacts',
  'type' => 'link',
  'relationship' => 'eciu_crm_resources_contacts',
  'source' => 'non-db',
  'module' => 'ECiu_crm_resources',
  'bean_name' => 'ECiu_crm_resources',
  'vname' => 'LBL_ECIU_CRM_RESOURCES_CONTACTS_FROM_ECIU_CRM_RESOURCES_TITLE',
);
