<?php
$module_name = 'igwt_ddc';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '80%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'KEY_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_KEY_ID',
    'width' => '20%',
    'default' => true,
  ),
);
?>
